/* tslint:disable */
/* eslint-disable */
export function process(ptr: Uint8Array): number;
